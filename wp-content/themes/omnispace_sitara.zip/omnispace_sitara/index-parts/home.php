<div class="o_home_featured">
    <img src="<?php echo get_template_directory_uri(); ?>/images/Cover.jpg" alt="image not found">
    <div class="o_home_header_box">
        <h1>What is your Story?</h1>
        <div class="o_home_header_box_subtitle">We listen to you and we will work with you for a better world</div>
        <button>Learn More</button>
    </div>
</div>
<div class="o_mission_container"> <!--- mission block ---->
    <h3 class="o_mission_title">OUR MISSION</h3>
    <div class="row">
        <div class="col-lg-6 o_mission_text">
            <p>We’re leading a global community of humanitarians to create a future where everyone can prosper.</p>
        </div>
        <div class="col-lg-6 o_mission_img">
            <img src="<?php echo get_template_directory_uri(); ?>/images/mission.JPG" alt="image not found">
        </div>
    </div>
</div>
<!-- Quotes section -->
<div class="o_events_wrapper">
    <div class="o_events_container">
    <h3 class="o_mission_title">QUOTES</h3>
        <div class="row">
            <div class="col-lg-4 o_events_left">
                <!--<img src="<?php echo get_template_directory_uri(); ?>/images/events-left.JPG" alt="">-->
                <section>
                    <p>“Look, the day is coming after each night, but I do not see any change in my life. If I am not  happy, how can I make others happy?”</p>

           <h6>– A mother from Modhumoti Adarsho Bidyaloy,  Pahardnaga, Saraspur, Kalia, Narail District, Bangladesh </h6>
                </section>
            </div>
            <div class="col-lg-4 o_events_middle">
                <!--<img src="<?php echo get_template_directory_uri(); ?>/images/events-middle.JPG" alt="">-->
                <section>
                    <p>“What happens when people open their hearts?”<br>
                    “They get better.”</p>
                    <h6> ― Haruki Murakami</h6>
                </section>
            </div>
             <div class="col-lg-4 o_events_left">
                <!--<img src="<?php echo get_template_directory_uri(); ?>/images/events-left.JPG" alt="">-->
                <section>
                    <p>“I do not know how to read and write, I never took part in any meeting like this. For the first time I have drawn my
                    hand on a piece of paper along with others. It was such a joy to find my  own handprint among others. 
                    I have realized that taking care of my own emotional needs will  help me to communicate better with my children”. 
                    </p>
                    <h6>– A mother of a student of class ten from Hazi  Gani School, Bangladesh </h6>
                </section>
            </div>
        </div>
    </div>
</div>
<!--<div class="o_stats_container">-->
<!--    <div class="o_home_stats row">-->
<!--        <div class="col-lg-3 o_stat_div">-->
<!--            <h1>37<span>m</span></h1>-->
<!--            <p>people reached across the world in 2020</p>    -->
<!--        </div>-->
<!--        <div class="col-lg-3 o_stat_div">-->
<!--            <h1>40<span>+</span></h1>-->
<!--            <p>people reached across the world in 2020</p>  -->
<!--        </div>-->
<!--        <div class="col-lg-3 o_stat_div">-->
<!--            <h1>5.6<span>k</span></h1>-->
<!--            <p>team members around the world</p>  -->
<!--        </div>-->
<!--        <div class="col-lg-3 o_stat_div">-->
<!--            <h1>85<span>%</span></h1>-->
<!--            <p>team members from the countries where they work</p>  -->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->

<!-- Our Work -->
<div class="o_press_release_container">
    <h3 class="o_mission_title">OUR WORK</h3>
    <div class="row">
        <div class="col-lg-4 o_pr_left">
            <img src="<?php echo get_template_directory_uri(); ?>/images/pr-left-pic.JPG" alt="">
            <!--<h4 class="n_robotoMedium">Our Work 1</h4>-->
            <p class="robotoRegular">SiTara’s Story is a non-profit charitable organisation registered in Australia that believes strong women build strong communities and nations.
            SiTara’s Story started its journey in 2017, with the aim of advancing equity for women and girls through advocacy, education, philanthropy and research.<br>
            <a class="robotoRegular" href="http://omnispace.co/Development/sitara_story/our-work"><strong>Read more »</strong></a></p>
        </div>
        <div class="col-lg-4 o_pr_middle">
            <img src="<?php echo get_template_directory_uri(); ?>/images/pr-middle-pic.JPG" alt="">
            <h4 class="n_robotoMedium" >Canberra chapter</h4>
            <p class="robotoRegular">Migrants make up some 28 per cent of the ACT’s population with new arrivals topping 10,000 in each of the past two financial years.
            The top 10 countries from where ACT gains its immigrants include China (11,900), India (10,900), Philippines, Vietnam, Sri Lanka, Malaysia.<br>
            <a class="robotoRegular" href="http://omnispace.co/Development/sitara_story/our-work/#canberra"><strong>Read more »</strong></a></p>
        </div>
        <div class="col-lg-4 o_pr_right">
        <img src="<?php echo get_template_directory_uri(); ?>/images/pr-right-pic.JPG" alt="">
            <h4 class="n_robotoMedium">Bangladesh Chapter</h4>
            <p class="robotoRegular">SiTara’s Story also tries to create a bridge between Canberra and developing countries, especially Bangladesh, where vulnerable groups such as women 
            and children require early education and intervention. SiTara’s Story chose to work with Bangladesh initially because UNICEF has already classified Bangladesh as
            a country of “high inequity”.  <br>
            <a class="robotoRegular" href="http://omnispace.co/Development/sitara_story/our-work/#bd"><strong>Read more »</strong></a></p>
        </div>
    </div>
</div>
<!-- Press Release -</a>
->
<!--<div class="o_press_release_container">-->
<!--    <h3 class="o_mission_title">PRESS RELEASE</h3>-->
<!--    <div class="row">-->
<!--        <div class="col-lg-4 o_pr_left">-->
<!--            <img src="<?php echo get_template_directory_uri(); ?>/images/pr-left-pic.JPG" alt="">-->
<!--            <h4>Lorem ipsum dolor sit amet, consectetuer adipiscing elit</h4>-->
<!--            <p>Sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis. <br><strong>Read more »</strong></p>-->
<!--        </div>-->
<!--        <div class="col-lg-4 o_pr_middle">-->
<!--            <img src="<?php echo get_template_directory_uri(); ?>/images/pr-middle-pic.JPG" alt="">-->
<!--            <h4>Lorem ipsum dolor sit amet, consectetuer adipiscing elit</h4>-->
<!--            <p>Sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis. <br><strong>Read more »</strong></p>-->
<!--        </div>-->
<!--        <div class="col-lg-4 o_pr_right">-->
<!--        <img src="<?php echo get_template_directory_uri(); ?>/images/pr-right-pic.JPG" alt="">-->
<!--            <h4>Lorem ipsum dolor sit amet, consectetuer adipiscing elit</h4>-->
<!--            <p>Sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis. <br><strong>Read more »</strong></p>-->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->

<!-- Media section -->
<div id="media"></div>
<div class="o_events_wrapper">
    <div class="o_events_container">
    <h3 class="o_mission_title o_events_title">SITARA'S STORY IN MEDIA</h3>
   <a href="https://hercanberra.com.au/life/conversation/new-mental-health-training-for-culturally-and-linguistically-diverse-volunteers/?fbclid=IwAR0eNCOAanATLZQF9cIAU3OdmYBmLaLID9n_lx5OEogq_Vkh-3MMFhnyKTM" class="n_link"><h5 class="o_mission_title o_events_title">HerCanberra article</h5></a>
   <a href="https://drive.google.com/file/d/1jXvk_kDeBnHq3h5waggjxO-vpm3P56tZ/view?usp=drivesdk" class="n_link"><h5 class="o_mission_title o_events_title">SiTara’s Story with ABC radio</h5></a>
   <a href="https://www.sbs.com.au/language/bangla/audio/you-have-to-be-aware-of-your-mental-health-along-with-physical-health-dr-shamaruh-mirza" class="n_link"><h5 class="o_mission_title o_events_title">SiTara’s Story with SBS Bangla</h5></a>
   <a href="https://www.sbs.com.au/language/bangla/audio/sitara-s-story-helping-rural-girls-to-change-their-outlook-on-life" class="n_link"><h5 class="o_mission_title o_events_title">SiTara’s Story with SBS Bangla</h5></a>
        
    </div>
</div>
<!-- Events section -->
<div class="o_events_wrapper">
    <div class="o_events_container">
    <h3 class="o_mission_title o_events_title">EVENTS</h3>
        <div class="row">
            <div class="col-lg-4 o_events_left">
                <img src="<?php echo get_template_directory_uri(); ?>/images/events-left.JPG" alt="">
                <section>
                    <p>Nummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation Lorem ipsum dolor sit amet, consectetuer adipiscing</p>
                    <h6>– Duis Autem</h6>
                </section>
            </div>
            <div class="col-lg-4 o_events_middle">
                <img src="<?php echo get_template_directory_uri(); ?>/images/events-middle.JPG" alt="">
                <section>
                    <p>Nummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation Lorem ipsum dolor sit amet, consectetuer adipiscing</p>
                    <h6>– Lellet Biranapillai</h6>
                </section>
            </div>
            <div class="col-lg-4 o_events_right">
                <img src="<?php echo get_template_directory_uri(); ?>/images/events-right.JPG" alt="">
                <section>
                    <p>Nummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation Lorem ipsum dolor sit amet, consectetuer adipiscing</p>
                    <h6>– Rilim Rebamat</h6>
                </section>
            </div>
        </div>
    </div>
</div>
<!-- Sign up section -->
<!--<div class="o_sign_up_conatiner">-->
<!--    <h3>Be part of the change</h3>-->
<!--    <p>Sign up to receive stories and updates from Sitara’s Story</p>-->
<!--    <form class="o_form_container">-->
<!--        <div class="form-group">-->
<!--            <div class="row">-->
<!--                <div class="col-lg-4">-->
<!--                    <input type="text" class="form-control-text" id="" placeholder="First Name*">-->
<!--                </div>-->
<!--                <div class="col-lg-4">-->
<!--                    <input type="text" class="form-control-text" id="" placeholder="Last Name*">-->
<!--                </div>-->
<!--                <div class="col-lg-4">-->
<!--                    <input type="text" class="form-control-text" id="" placeholder="Email*">-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </form>-->
<!--</div>-->