<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package omnispace_sitara
 */

get_header();
?>
div class="n_allEventsSingles">
   <br><br><br><br>
   <!--Home taxt and bottombar -->
   <p class="n_homebar">HOME>
      <?php $category = get_the_category();
         $firstCategory = $category[0]->cat_name; echo $firstCategory;?>
   </p>
   <br>
   <?php
      // Start the loop.
      while ( have_posts() ) : the_post(); ?>
   <div class="col-xl-10 offset-xl-1 col-12" >
      <h3 class="n_allEventsHeading"> <?php echo the_title(); ?></h3>
   </div>
<!--
   <div class="col-xl-10  offset-xl-1">
      <?php  echo the_post_thumbnail(); ?>
   </div>
-->
   <div class="col-xl-10 offset-xl-1 col-12 video-containerroff n_t">
     
      <?php echo the_content(); ?>
   </div>
   <?php
      endwhile;
      ?>
</div>

<?php
get_sidebar();
get_footer();
