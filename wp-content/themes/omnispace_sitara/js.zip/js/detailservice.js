$(document).ready(function() {
     var loc=window.location;
     test(loc); 
     //end of scripting to location
     $( ".first_square" ).click(function() {
        //shadingAndClearing("#r_1");
      });
      $( ".second_square" ).click(function() {
        //shadingAndClearing("#r_3");
      });
      $( ".third_square" ).click(function() {
        //shadingAndClearing("#r_5");
      });
      $( ".fourth_square" ).click(function() {
        //shadingAndClearing("#r_7");
      });
      $( ".fifth_square" ).click(function() {
        //shadingAndClearing("#r_2");
      });
      $( ".sixth_square" ).click(function() {
        //shadingAndClearing("#r_4");
      });
      $( ".seventh_square" ).click(function() {
        //shadingAndClearing("#r_6");
      });
      $( ".eighth_square" ).click(function() {
        //shadingAndClearing("#r_8");
      });
      console.log("coloring has been disabled");
    });

    function test(res){
        var testStr = res+"";
        var val=parseInt(testStr.charAt(testStr.length-1));
        //stylingOption(val);
    }
    function stylingOption(ids){
        if(ids==0){
            $("#r_1").css("background-color", "silver");
        }else if(ids==1){
            $("#r_3").css("background-color", "silver");
        }
        else if(ids==3){
            $("#r_5").css("background-color", "silver");
        }else if(ids==5){
            $("#r_7").css("background-color", "silver");
        }else if(ids==9){
            $("#r_2").css("background-color", "silver");
        }else if(ids==2){
            $("#r_4").css("background-color", "silver");
        }else if(ids==4){
            $("#r_6").css("background-color", "silver");
        }else if(ids==6){
            $("#r_8").css("background-color", "silver");
        }
    }

    function shadingAndClearing(id){
        var i;
        for (i = 1; i < 9; i++) {
             all_id="#r_"+i;
            $(all_id).css("background-color", "white");
        }
        $(id).css("background-color", "silver");
    }