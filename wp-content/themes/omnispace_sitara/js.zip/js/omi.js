$(window).on('scroll', function() {
    if ($(this).scrollTop()>=120) { // this refers to window
        $(".o_menu_container").addClass("o_menu_container_sticky");
        $(".o_logo1").css({"height": "70px", "width": "95px"});
        $(".o_social_media").css("display", "none")
        $(".o_menu_items").css("margin-top", "20px")
        $(".o_top_logo_wrap").css("text-align", "center")
    }
    else{
        $(".o_menu_container").removeClass("o_menu_container_sticky");
        $(".o_logo1").css({"height": "110px", "width": "140px"});
        $(".o_social_media").css("display", "block")
        $(".o_menu_items").css("margin-top", "0px")
        $(".o_top_logo_wrap").css("text-align", "center")
        
    }
})

//scripts for mobile menu. 
$(document).ready(function(){
                  $("#o_mobile_menu_hamburger").click(function(){
                    $("#o_mobile_menu").slideDown("slow");
                  });
                });

$(document).ready(function(){
                  $("#o_mobile_menu_cross_button").click(function(){
                    $("#o_mobile_menu").slideUp("slow");
                  });
                });           