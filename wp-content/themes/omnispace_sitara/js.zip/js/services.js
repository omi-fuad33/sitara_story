/**
 * File services.js.
 *
 * this code is written to make div square in response with the screen size
 *
 *
 */

	$(document).ready(function(){
      var locPrefix = "http://abcconnectbd.com/services/";
      $(".r_squarer").height($(".r_squarer").width());
      $(window).resize(function(){
        $(".r_squarer").height($(".r_squarer").width());
      });
      $(".first_square").click(function(){  
        window.location=locPrefix+"#r_0";
      });
      $(".second_square").click(function(){
        window.location=locPrefix+"#r_1";
      });
      $(".third_square").click(function(){
        window.location=locPrefix+"#r_3";
      });
      $(".fourth_square").click(function(){
        window.location=locPrefix+"#r_5";
      });
      $(".fifth_square").click(function(){
        window.location=locPrefix+"#r_9";
      });
      $(".sixth_square").click(function(){
        window.location=locPrefix+"#r_2";
      });
      $(".seventh_square").click(function(){
        window.location=locPrefix+"#r_4";
      });
      $(".eighth_square").click(function(){
        window.location=locPrefix+"#r_6";
      });
    
  });

